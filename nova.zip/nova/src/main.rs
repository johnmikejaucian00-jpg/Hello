//! nova - a small, fast Minecraft: Java Edition launcher.
//! Downloads everything from Mojang in parallel, verifies SHA-1, and starts the game
//! with tuned JVM flags. Offline (no Microsoft login) for now.

use anyhow::{bail, Context, Result};
use clap::Parser;
use futures::stream::{self, StreamExt};
use md5::Md5;
use serde::Deserialize;
use sha1::{Digest, Sha1};
use std::collections::{HashMap, HashSet};
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Arc;
use tokio::fs;

const MANIFEST: &str = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json";
const ASSET_URL: &str = "https://resources.download.minecraft.net";

// ---------------------------------------------------------------- CLI

#[derive(Parser)]
#[command(name = "nova", about = "Fast Rust Minecraft launcher")]
struct Cli {
    /// Version id (e.g. 1.21.4) or "latest"
    #[arg(default_value = "latest")]
    version: String,
    /// Offline player name
    #[arg(long, default_value = "Player")]
    name: String,
    /// RAM in GB
    #[arg(long, default_value_t = 4)]
    ram: u32,
    /// Path to the java executable (must match the Java version the game needs)
    #[arg(long, default_value = "java")]
    java: String,
    /// Game folder (default: ~/.nova)
    #[arg(long)]
    dir: Option<PathBuf>,
    /// JVM garbage collector tuning: g1 | zgc | none
    #[arg(long, default_value = "g1")]
    gc: String,
    /// List recent release versions and exit
    #[arg(long)]
    list: bool,
    /// Download only, do not start the game
    #[arg(long)]
    download_only: bool,
}

// ---------------------------------------------------------------- Mojang JSON

#[derive(Deserialize)]
struct Manifest {
    latest: Latest,
    versions: Vec<VersionEntry>,
}
#[derive(Deserialize)]
struct Latest {
    release: String,
}
#[derive(Deserialize)]
struct VersionEntry {
    id: String,
    #[serde(rename = "type")]
    kind: String,
    url: String,
    sha1: String,
}

#[derive(Deserialize)]
struct VersionJson {
    #[serde(rename = "mainClass")]
    main_class: String,
    #[serde(rename = "assetIndex")]
    asset_index: AssetIndexRef,
    downloads: VersionDownloads,
    libraries: Vec<Library>,
    arguments: Option<Arguments>,
    #[serde(rename = "minecraftArguments")]
    minecraft_arguments: Option<String>,
    #[serde(rename = "javaVersion")]
    java_version: Option<JavaVersion>,
    #[serde(rename = "type")]
    kind: Option<String>,
}
#[derive(Deserialize)]
struct JavaVersion {
    #[serde(rename = "majorVersion")]
    major: u32,
}
#[derive(Deserialize)]
struct AssetIndexRef {
    id: String,
    url: String,
    sha1: String,
}
#[derive(Deserialize)]
struct VersionDownloads {
    client: Artifact,
}
#[derive(Deserialize, Clone)]
struct Artifact {
    url: String,
    sha1: String,
    path: Option<String>,
}
#[derive(Deserialize)]
struct Library {
    downloads: Option<LibDownloads>,
    rules: Option<Vec<Rule>>,
    natives: Option<HashMap<String, String>>,
}
#[derive(Deserialize)]
struct LibDownloads {
    artifact: Option<Artifact>,
    classifiers: Option<HashMap<String, Artifact>>,
}
#[derive(Deserialize)]
struct Rule {
    action: String,
    os: Option<OsRule>,
    features: Option<HashMap<String, bool>>,
}
#[derive(Deserialize)]
struct OsRule {
    name: Option<String>,
    arch: Option<String>,
}
#[derive(Deserialize)]
struct Arguments {
    #[serde(default)]
    game: Vec<Arg>,
    #[serde(default)]
    jvm: Vec<Arg>,
}
#[derive(Deserialize)]
#[serde(untagged)]
enum Arg {
    Plain(String),
    Ruled { rules: Vec<Rule>, value: StrOrVec },
}
#[derive(Deserialize)]
#[serde(untagged)]
enum StrOrVec {
    One(String),
    Many(Vec<String>),
}
#[derive(Deserialize)]
struct AssetIndex {
    objects: HashMap<String, AssetObj>,
}
#[derive(Deserialize)]
struct AssetObj {
    hash: String,
}

// ---------------------------------------------------------------- rules / OS

fn os_name() -> &'static str {
    if cfg!(target_os = "windows") {
        "windows"
    } else if cfg!(target_os = "macos") {
        "osx"
    } else {
        "linux"
    }
}

fn rule_matches(r: &Rule) -> bool {
    // we enable no launcher features (demo mode, custom resolution, ...)
    if let Some(f) = &r.features {
        if f.values().any(|b| *b) {
            return false;
        }
    }
    if let Some(os) = &r.os {
        if let Some(n) = &os.name {
            if n != os_name() {
                return false;
            }
        }
        if let Some(a) = &os.arch {
            let cur = match std::env::consts::ARCH {
                "aarch64" => "arm64",
                x => x,
            };
            if a != cur {
                return false;
            }
        }
    }
    true
}

fn rules_ok(rules: &[Rule]) -> bool {
    if rules.is_empty() {
        return true;
    }
    let mut allowed = false;
    for r in rules {
        if rule_matches(r) {
            allowed = r.action == "allow";
        }
    }
    allowed
}

// ---------------------------------------------------------------- downloading

struct Job {
    url: String,
    path: PathBuf,
    sha1: String,
    /// skip hashing files that already exist (used for the thousands of asset objects)
    trust: bool,
}

async fn fetch(c: &reqwest::Client, url: &str) -> Result<Vec<u8>> {
    Ok(c.get(url).send().await?.error_for_status()?.bytes().await?.to_vec())
}

async fn ensure(c: &reqwest::Client, url: &str, path: &Path, sha1: &str, trust: bool) -> Result<()> {
    if path.exists() {
        if trust {
            return Ok(());
        }
        let data = fs::read(path).await?;
        if hex::encode(Sha1::digest(&data)) == sha1 {
            return Ok(());
        }
    }
    if let Some(p) = path.parent() {
        fs::create_dir_all(p).await?;
    }
    let mut last: Option<anyhow::Error> = None;
    for _ in 0..3 {
        match fetch(c, url).await {
            Ok(bytes) => {
                if hex::encode(Sha1::digest(&bytes)) != sha1 {
                    last = Some(anyhow::anyhow!("hash mismatch"));
                    continue;
                }
                let tmp = path.with_extension("part");
                fs::write(&tmp, &bytes).await?;
                fs::rename(&tmp, path).await?;
                return Ok(());
            }
            Err(e) => last = Some(e),
        }
    }
    Err(last.unwrap()).with_context(|| format!("downloading {url}"))
}

async fn run_jobs(c: &reqwest::Client, jobs: Vec<Job>, conc: usize) -> Result<()> {
    let total = jobs.len();
    let done = Arc::new(AtomicUsize::new(0));
    let mut s = stream::iter(jobs)
        .map(|j| {
            let c = c.clone();
            let done = done.clone();
            async move {
                let r = ensure(&c, &j.url, &j.path, &j.sha1, j.trust).await;
                let n = done.fetch_add(1, Ordering::Relaxed) + 1;
                if n % 250 == 0 || n == total {
                    eprintln!("  checked {n}/{total}");
                }
                r
            }
        })
        .buffer_unordered(conc);
    while let Some(r) = s.next().await {
        r?;
    }
    Ok(())
}

fn extract_natives(jar: &Path, out: &Path) -> Result<()> {
    let mut z = zip::ZipArchive::new(std::fs::File::open(jar)?)?;
    for i in 0..z.len() {
        let mut e = z.by_index(i)?;
        let name = e.name().to_string();
        if e.is_dir() || name.starts_with("META-INF") {
            continue;
        }
        let Some(file) = Path::new(&name).file_name() else { continue };
        let mut o = std::fs::File::create(out.join(file))?;
        std::io::copy(&mut e, &mut o)?;
    }
    Ok(())
}

// ---------------------------------------------------------------- launch helpers

fn offline_uuid(name: &str) -> String {
    let mut d = Md5::digest(format!("OfflinePlayer:{name}").as_bytes());
    d[6] = (d[6] & 0x0f) | 0x30;
    d[8] = (d[8] & 0x3f) | 0x80;
    let h = hex::encode(d);
    format!("{}-{}-{}-{}-{}", &h[0..8], &h[8..12], &h[12..16], &h[16..20], &h[20..32])
}

fn subst(s: &str, vars: &HashMap<&str, String>) -> String {
    let mut out = s.to_string();
    for (k, v) in vars {
        out = out.replace(&format!("${{{k}}}"), v);
    }
    out
}

fn expand(args: &[Arg], vars: &HashMap<&str, String>) -> Vec<String> {
    let mut out = Vec::new();
    for a in args {
        match a {
            Arg::Plain(s) => out.push(subst(s, vars)),
            Arg::Ruled { rules, value } => {
                if rules_ok(rules) {
                    match value {
                        StrOrVec::One(s) => out.push(subst(s, vars)),
                        StrOrVec::Many(v) => out.extend(v.iter().map(|s| subst(s, vars))),
                    }
                }
            }
        }
    }
    out
}

fn gc_flags(kind: &str) -> Vec<String> {
    let f: &[&str] = match kind {
        // G1 tuned for low stutter (Aikar-style, minus the server-only pre-touch)
        "g1" => &[
            "-XX:+UseG1GC", "-XX:+ParallelRefProcEnabled", "-XX:MaxGCPauseMillis=200",
            "-XX:+UnlockExperimentalVMOptions", "-XX:+DisableExplicitGC",
            "-XX:G1NewSizePercent=30", "-XX:G1MaxNewSizePercent=40", "-XX:G1HeapRegionSize=8M",
            "-XX:G1ReservePercent=20", "-XX:G1HeapWastePercent=5", "-XX:G1MixedGCCountTarget=4",
            "-XX:InitiatingHeapOccupancyPercent=15", "-XX:G1MixedGCLiveThresholdPercent=90",
            "-XX:G1RSetUpdatingPauseTimePercent=5", "-XX:SurvivorRatio=32",
            "-XX:+PerfDisableSharedMem", "-XX:MaxTenuringThreshold=1",
        ],
        // near-zero pauses, uses more RAM (generational by default on Java 23+)
        "zgc" => &["-XX:+UseZGC", "-XX:+DisableExplicitGC", "-XX:+PerfDisableSharedMem"],
        _ => &[],
    };
    f.iter().map(|s| s.to_string()).collect()
}

fn default_dir() -> PathBuf {
    let home = std::env::var("HOME").or_else(|_| std::env::var("USERPROFILE")).unwrap_or_else(|_| ".".into());
    PathBuf::from(home).join(".nova")
}

// ---------------------------------------------------------------- main

#[tokio::main]
async fn main() -> Result<()> {
    let cli = Cli::parse();
    let root = cli.dir.clone().unwrap_or_else(default_dir);
    let http = reqwest::Client::builder().user_agent("nova-launcher/0.1").build()?;

    let manifest: Manifest = http.get(MANIFEST).send().await?.error_for_status()?.json().await?;
    if cli.list {
        for v in manifest.versions.iter().filter(|v| v.kind == "release").take(30) {
            println!("{}", v.id);
        }
        return Ok(());
    }

    let id = if cli.version == "latest" { manifest.latest.release.clone() } else { cli.version.clone() };
    let entry = manifest.versions.iter().find(|v| v.id == id).with_context(|| format!("unknown version {id} (try --list)"))?;

    // version json
    let vdir = root.join("versions").join(&id);
    let vjson_path = vdir.join(format!("{id}.json"));
    ensure(&http, &entry.url, &vjson_path, &entry.sha1, false).await?;
    let v: VersionJson = serde_json::from_slice(&fs::read(&vjson_path).await?)?;
    if let Some(j) = &v.java_version {
        println!("Minecraft {id} needs Java {} or newer (using `{}`)", j.major, cli.java);
    }

    let libs = root.join("libraries");
    let natives_dir = root.join("natives").join(&id);
    fs::create_dir_all(&natives_dir).await?;

    let mut jobs: Vec<Job> = Vec::new();
    let mut seen: HashSet<PathBuf> = HashSet::new();
    let mut classpath: Vec<PathBuf> = Vec::new();
    let mut native_jars: Vec<PathBuf> = Vec::new();
    let mut add = |jobs: &mut Vec<Job>, a: &Artifact, path: PathBuf, trust: bool| {
        if seen.insert(path.clone()) {
            jobs.push(Job { url: a.url.clone(), path, sha1: a.sha1.clone(), trust });
        }
    };

    for lib in &v.libraries {
        if !rules_ok(lib.rules.as_deref().unwrap_or(&[])) {
            continue;
        }
        let Some(d) = &lib.downloads else { continue };
        if let Some(a) = &d.artifact {
            let p = libs.join(a.path.as_ref().context("library without path")?);
            add(&mut jobs, a, p.clone(), false);
            classpath.push(p);
        }
        // old-style natives (<= 1.18): separate classifier jar, extracted to the natives folder
        if let (Some(n), Some(cl)) = (&lib.natives, &d.classifiers) {
            if let Some(k) = n.get(os_name()) {
                let k = k.replace("${arch}", if cfg!(target_pointer_width = "64") { "64" } else { "32" });
                if let Some(a) = cl.get(&k) {
                    let p = libs.join(a.path.as_ref().context("native without path")?);
                    add(&mut jobs, a, p.clone(), false);
                    native_jars.push(p);
                }
            }
        }
    }

    let client_jar = vdir.join(format!("{id}.jar"));
    add(&mut jobs, &v.downloads.client, client_jar.clone(), false);
    classpath.push(client_jar);

    // asset index + objects
    let assets_root = root.join("assets");
    let index_path = assets_root.join("indexes").join(format!("{}.json", v.asset_index.id));
    ensure(&http, &v.asset_index.url, &index_path, &v.asset_index.sha1, false).await?;
    let index: AssetIndex = serde_json::from_slice(&fs::read(&index_path).await?)?;
    for o in index.objects.values() {
        let sub = &o.hash[..2];
        let a = Artifact { url: format!("{ASSET_URL}/{sub}/{}", o.hash), sha1: o.hash.clone(), path: None };
        add(&mut jobs, &a, assets_root.join("objects").join(sub).join(&o.hash), true);
    }

    println!("Checking {} files...", jobs.len());
    run_jobs(&http, jobs, 64).await?;
    for j in &native_jars {
        extract_natives(j, &natives_dir)?;
    }
    if cli.download_only {
        println!("Done.");
        return Ok(());
    }

    // arguments
    let sep = if cfg!(windows) { ";" } else { ":" };
    let cp = classpath.iter().map(|p| p.to_string_lossy().to_string()).collect::<Vec<_>>().join(sep);
    let vars: HashMap<&str, String> = HashMap::from([
        ("auth_player_name", cli.name.clone()),
        ("auth_uuid", offline_uuid(&cli.name)),
        ("auth_access_token", "0".into()),
        ("auth_session", "0".into()),
        ("clientid", "0".into()),
        ("auth_xuid", "0".into()),
        ("user_type", "legacy".into()),
        ("user_properties", "{}".into()),
        ("version_name", id.clone()),
        ("version_type", v.kind.clone().unwrap_or_else(|| "release".into())),
        ("game_directory", root.to_string_lossy().to_string()),
        ("assets_root", assets_root.to_string_lossy().to_string()),
        ("game_assets", assets_root.to_string_lossy().to_string()),
        ("assets_index_name", v.asset_index.id.clone()),
        ("natives_directory", natives_dir.to_string_lossy().to_string()),
        ("library_directory", libs.to_string_lossy().to_string()),
        ("classpath_separator", sep.into()),
        ("classpath", cp),
        ("launcher_name", "nova".into()),
        ("launcher_version", "0.1".into()),
    ]);

    let mut jvm = vec![format!("-Xms{}G", cli.ram), format!("-Xmx{}G", cli.ram)];
    jvm.extend(gc_flags(&cli.gc));
    let (jvm_args, game_args) = match &v.arguments {
        Some(a) => (expand(&a.jvm, &vars), expand(&a.game, &vars)),
        None => (
            vec![subst("-Djava.library.path=${natives_directory}", &vars), "-cp".into(), subst("${classpath}", &vars)],
            v.minecraft_arguments.clone().unwrap_or_default().split_whitespace().map(|s| subst(s, &vars)).collect(),
        ),
    };
    jvm.extend(jvm_args);

    println!("Launching {id} as {} ...", cli.name);
    let status = std::process::Command::new(&cli.java)
        .args(&jvm)
        .arg(&v.main_class)
        .args(&game_args)
        .current_dir(&root)
        .status()
        .with_context(|| format!("could not start `{}`: install the right Java or pass --java", cli.java))?;
    if !status.success() {
        bail!("game exited with {status}");
    }
    Ok(())
}
